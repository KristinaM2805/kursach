using System;

namespace DarkRoomCinema.Models
{
    public class Show
    {
        public string MovieTitle { get; set; }
        public DateTime ShowDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public int OccupiedSeats { get; set; }
        public decimal TicketCost { get; set; }
    }
}