using System;

namespace DarkRoomCinema.Models
{
    public class Movie
    {
        public int Code { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal RentalCost { get; set; }
        public decimal Revenue { get; set; }
    }
}