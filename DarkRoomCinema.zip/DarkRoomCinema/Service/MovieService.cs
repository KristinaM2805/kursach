using System;
using System.Collections.Generic;
using System.Linq;
using DarkRoomCinema.Models;

namespace DarkRoomCinema.Services
{
    public class MovieService
    {
        private List<Movie> _movies;
        private List<Show> _shows;

        public MovieService()
        {
            _movies = new List<Movie>();
            _shows = new List<Show>();
        }

        public void AddMovie(Movie movie)
        {
            _movies.Add(movie);
        }

        public void RemoveMovie(int code)
        {
            var movie = _movies.FirstOrDefault(m => m.Code == code);
            if (movie != null)
            {
                _movies.Remove(movie);
                _shows.RemoveAll(s => s.MovieTitle == movie.Title);
            }
        }

        public void AddShow(Show show)
        {
            _shows.Add(show);
            var movie = _movies.FirstOrDefault(m => m.Title == show.MovieTitle);
            if (movie != null)
            {
                movie.Revenue += show.TicketCost;
            }
        }

        public List<Movie> GetMovies()
        {
            return _movies;
        }

        public List<Show> GetShows()
        {
            return _shows;
        }

        public List<Movie> SortMoviesByTitle()
        {
            return _movies.OrderBy(m => m.Title).ToList();
        }

        public List<Movie> SortMoviesByGenre()
        {
            return _movies.OrderBy(m => m.Genre).ToList();
        }

        public List<Movie> SortMoviesByRentalCost()
        {
            return _movies.OrderBy(m => m.RentalCost).ToList();
        }

        public List<Show> SortShowsByDate()
        {
            return _shows.OrderBy(s => s.ShowDate).ToList();
        }

        public List<Show> SortShowsByStartTime()
        {
            return _shows.OrderBy(s => s.StartTime).ToList();
        }

        public List<Show> SortShowsByOccupiedSeats()
        {
            return _shows.OrderBy(s => s.OccupiedSeats).ToList();
        }

        public List<Show> GetShowsByMovieTitle(string title)
        {
            return _shows.Where(s => s.MovieTitle == title).ToList();
        }

        public List<Show> GetShowsByDate(DateTime date)
        {
            return _shows.Where(s => s.ShowDate == date).ToList();
        }

        public List<Show> GetShowsByStartTime(TimeSpan time)
        {
            return _shows.Where(s => s.StartTime == time).ToList();
        }

        public List<Show> GetShowsByGenre(string genre)
        {
            var movies = _movies.Where(m => m.Genre == genre).Select(m => m.Title).ToList();
            return _shows.Where(s => movies.Contains(s.MovieTitle)).ToList();
        }
    }
}