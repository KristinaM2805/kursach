using System.Collections.ObjectModel;
using DarkRoomCinema.Models;
using DarkRoomCinema.Services;

namespace DarkRoomCinema.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        private readonly MovieService _movieService;

        public ObservableCollection<Movie> Movies { get; }
        public ObservableCollection<Show> Shows { get; }

        public MainWindowViewModel()
        {
            _movieService = new MovieService();
            Movies = new ObservableCollection<Movie>(_movieService.GetMovies());
            Shows = new ObservableCollection<Show>(_movieService.GetShows());
        }
    }
}