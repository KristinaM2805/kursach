using ReactiveUI;

namespace DarkRoomCinema.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}