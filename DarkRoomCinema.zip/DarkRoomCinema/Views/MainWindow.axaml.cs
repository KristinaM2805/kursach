using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using DarkRoomCinema.ViewModels;

namespace DarkRoomCinema.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowViewModel();
        }
    }
}